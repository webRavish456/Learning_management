const Menuitems = [
    
    {
        icon: '/sidebar/dashboard.png',
        label: "Dashboard",
        href: "/",
    },
    {
      icon: '/sidebar/course.png',
      label: "Course",
      href: "/course",
    },
    {
       icon: "/sidebar/students.png",
       label: "Student",
       href: "/student",
      },
    {
      icon: "/sidebar/faculty.png",
      label: "Faculty",
      href: "/faculty",
    },
    {
      icon: "/sidebar/assignments.png",
      label: "Assignments",
      href: "/assignments",
    },
    {
      icon: "/sidebar/exam.png",
      label: "Exam",
      href: "/exam",
    },
    {
      icon: "/sidebar/finance.png",
      label: "Finance",
      href: "/finance",
    },

];

export default Menuitems;